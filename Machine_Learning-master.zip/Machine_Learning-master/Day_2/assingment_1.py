import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#reading data
data = pd.read_csv("E:\\Machine Learning\Data\\assingment_1_data.csv")

##not considering the rows having missing data
#data.dropna(inplace=True)

##filling the missing data with 0
#data.fillna(0,inplace=True)

#collecting X and Y
X=data['List_1'].values
Y=data['List_2'].values

#mean X and Y
mean_x = np.mean(X)
mean_y = np.mean(Y)

#total values
n=len(X)

#calculate b0 and b1
num=0
denom=0

for i in range(n):
        num += (X[i] - mean_x) * (Y[i] - mean_y)
        denom += (X[i] - mean_x) ** 2

b1 = num/denom
b0 = mean_y - (b1 * mean_x)

print(b1, b0)

#calculating RMSE
rmse=0

for i in range(n):
    y_pred = b0 + b1*X[i]
rmse += np.sqrt(rmse/n)
print("rmse = ",rmse)

# R2 calculation
ssr=0
sst=0
for i in range(n):
    y_pred = b0 + b1*X[i]
    sst += (Y[i] - mean_y)**2
    ssr += (Y[i] - y_pred)**2
r2 = 1 - (ssr/sst)
print("R2= ", r2)

#MAE (mean absolute error)
mae=0
for i in range(n):
    y_pred = b0 + b1 * X[i]
    mae += (Y[i] - y_pred)
mae=mae/n
print("MAE= ", mae)


#plot output
plt.scatter(X, Y,  color='black')
plt.plot(X, Y, color='blue', linewidth=2)
plt.show()


