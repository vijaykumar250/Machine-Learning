#import package
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score,mean_squared_error

#import dataset
df = pd.read_csv("E:\Machine Learning\Data\data1.csv")
#print(df)
#plt.plot(df)
#impute dataset
#df.fillna(np.mean(ht),inplace=True)

#train X and Y
train_X = df["ht"][:-1].values
test_X = df["ht"][-1:].values
train_X = np.reshape(train_X,(-1,1))
test_X = np.reshape(test_X,(-1,1))
#print(train_X)
#print(test_X)

train_Y = df["wt"][:-1].values
test_Y = df["wt"][-1:].values
train_Y = np.reshape(train_Y,(-1,1))
test_Y = np.reshape(test_Y,(-1,1))
#print(train_Y)
#print(test_Y)

#build the model
model = LinearRegression()

#fit the model
model.fit(train_X,train_Y)
print("coeff: ",model.coef_)
print("intercept: ",model.intercept_)

#evaluate the model
score = model.score(train_X,train_Y)
print(score)
plt.plot(score)
#plt.show()

predict = model.predict(test_X)
print(predict)

rmse=mean_squared_error(test_Y,predict)
r2=r2_score(test_Y,predict)

print("RMSE:",rmse)
print("R2:",r2)
plt.plot(train_X,train_Y)
plt.plot(len(df),test_Y,"go")
plt.plot(len(df),predict,"rx")
plt.show()