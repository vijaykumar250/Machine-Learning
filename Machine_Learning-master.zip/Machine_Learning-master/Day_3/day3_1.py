#import package
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error,r2_score

#import dataset
df = pd.read_csv("https://raw.githubusercontent.com/DLMLPYRTRAINING/Day3/master/Datasets/Linear1.csv")

#training X and Y
train_X = df['x'][:-1].values
train_Y = df['y'][:-1].values
train_X = np.reshape(train_X,(-1,1))
train_Y = np.reshape(train_Y,(-1,1))

#test X and Y
test_X = df['x'][-1:].values
test_Y = df['y'][-1:].values
test_X = np.reshape(test_X,(-1,1))
test_Y = np.reshape(test_Y,(-1,1))
#build model
model = LinearRegression()

#fit the model
model.fit(train_X,train_Y)
coefficient = model.coef_
intercept = model.intercept_
print("coeff: ",coefficient)
print("intercept: ",intercept)
#print(train_X)

point = [intercept + coefficient[0]*i[0] for i in train_X]
print(point)
plt.plot(point,'r--')




#score the model
score = model.score(train_X,train_Y)
print("Score = ",score)

#predict the model
predict = model.predict(test_X)
print(predict)

print("RMSE = ", (mean_squared_error(test_Y,predict)))
print("R2 = ",r2_score(test_Y,predict))

plt.plot(train_X,train_Y)
plt.plot(len(df),test_Y,"go")
plt.plot(len(df),predict,"rx")
plt.show()
