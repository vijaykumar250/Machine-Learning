#import packages
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.linear_model import LinearRegression

#import dataset
df = pd.read_csv("https://raw.githubusercontent.com/DLMLPYRTRAINING/Day3/master/Datasets/Linear2.csv")

#training X and Y
train_X = df['x'][:-1].values
train_Y = df['y'][:-1].values
train_X = np.reshape(train_X,(-1,1))
train_Y = np.reshape(train_Y,(-1,1))

#test X and Y
test_X = df['x'][-1:].values
test_Y = df['y'][-1:].values
test_X = np.reshape(test_X,(-1,1))
test_Y = np.reshape(test_Y,(-1,1))

#build the model
model = LinearRegression()

#fit the model
model.fit(train_X,train_Y)

coef = model.coef_
intercept = model.intercept_
print("coefficient :",coef)
print("Intercept :",intercept)

point = [intercept + coef[0]*i[0] for i in train_X]
plt.plot(point)

#score the model
score = model.score(train_X,train_Y)
print("score :",score)

#predict the model
predict = model.predict(test_X)
print("predict :",predict)

#print RMSE and R2
print("RMSE :",mean_squared_error(test_Y,predict))
print("R2 :",r2_score(test_Y,predict))

#plotting
plt.plot(train_X,train_Y)
plt.plot(len(df),test_Y,"go")
plt.plot(len(df),predict,"rx")
plt.gca().legend(('Linear Regression Line','data','test_y','prediction'))
plt.show()