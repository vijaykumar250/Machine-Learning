import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

data = pd.read_csv("https://raw.githubusercontent.com/DLMLPYRTRAINING/Day3/master/Datasets/Classification.csv")

data.loc[data["Class"] == "Single_Digit", "Class"] = 0
data.loc[data["Class"] == "Double_Digit", "Class"] = 1
X = data["Number"][:-3].values.reshape(-1, 1)
Y = data["Class"][:-3].values.reshape(-1, 1)

x_test = data["Number"][-3:].values.reshape(-1, 1)
y_test = data["Class"][-3:].values.reshape(-1, 1)

# build model
model = KNeighborsClassifier(n_neighbors=2)

# train model
model.fit(X,Y.ravel())

# score model
score = model.score(X,Y.ravel())
print("Score:\n", score)

predict = model.predict(x_test)
print("Prediction Feature:\n", x_test)
print("Actual Value:\n",y_test)
print("Prediction Value:\n", predict)