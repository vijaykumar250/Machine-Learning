from keras.models import model_from_yaml
import data_gen as dg
import numpy as np
from keras.utils import to_categorical
import os
import matplotlib.pyplot as plt
from random import randrange

def model_loader(model_name="", file_path = "E:\Machine Learning\PROJECT\Models"):
    if model_name != "":
        # load YAML and create model
        yaml_file = open(file_path + os.sep + model_name + ".yaml", 'r')
        loaded_model_yaml = yaml_file.read()
        yaml_file.close()
        loaded_model = model_from_yaml(loaded_model_yaml)
        # load weights into new model
        loaded_model.load_weights(file_path + os.sep + model_name + ".h5")
        print("Loaded model from disk")

        return loaded_model
        # # evaluate loaded model on test data
        # loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
        # score = loaded_model.evaluate(X, Y, verbose=0)
        # print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))

def run_random_imges():
    train_images, train_labels, test_images, test_labels = dg.load_data(split_ratio=0.8,total_row=1000)

    # test_images.shape will return no. of images, width, height, channel info
    # test_labels.shape will return the total no. of test data
    print('Testing data shape : ', test_images.shape, test_labels.shape)
    print(test_labels)

    # Find the unique numbers from the train labels
    classes = np.unique(test_labels)
    nClasses = len(classes)
    print('Total number of outputs : ', nClasses)   #0, 1, 2, 3 for blank, green, yellow, red. 4 classes
    print('Output classes : ', classes)             #classes are [0,1,2,3]

    # ==============================================================================
    # Preprocess the Data
    # Find the shape of input images and create the variable input_shape
    nRows, nCols, nDims = test_images.shape[1:]
    test_data = test_images.reshape(test_images.shape[0], nRows, nCols, nDims)

    # Change to float datatype
    test_data = test_data.astype('float32')

    # Scale the data to lie between 0 to 1
    test_data /= 255

    # Change the labels from integer to categorical data
    test_labels_one_hot = to_categorical(test_labels)

    # Display the change for category label using one-hot encoding
    print('Original label 0 : ', test_labels)
    print('After conversion to categorical ( one-hot ) : ', test_labels_one_hot)

    model_name = "Model1_20180703_160325"
    model = model_loader(model_name=model_name)
    # # evaluate loaded model on test data
    model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
    # score = model.evaluate(test_images, test_labels_one_hot, verbose=1)
    # print("%s: %.2f%%" % (model.metrics_names[1], score[1] * 100))

    prediction = model.predict_classes(test_images)
    print("prediction:", prediction)
    print("Actual:    ", test_labels.reshape(1, -1)[0])

    for i in range(0,len(test_data)):
        rand_data = randrange(0,len(test_data))
    print(prediction[rand_data])
    # print(test_labels.reshape(1, -1)[0][rand_data])
    #print(rand_data)


    if prediction[rand_data] == 0:
        print("KEEP GOING....")
    if prediction[rand_data] == 1:
        print("GO")
    if prediction[rand_data] == 2:
        print("READY")
    if prediction[rand_data] == 3:
        print("STOP !")

    # # is no. of rows is 10 then it will be useful and split ratio = 0
    # if rand_data == 2:
    #     print("KEEP GOING....")
    # if rand_data == 6:
    #     print("GO")
    # if rand_data == 0 or rand_data==1 or rand_data==3 or rand_data==4 or rand_data==5:
    #     print("READY")
    # if rand_data == 7 or rand_data == 8 or rand_data==9:
    #     print("STOP !")

    plt.imshow(test_images[rand_data, :, :], cmap='gray')
    plt.title("Ground Truth : {} Prediction: {}".format(test_labels[rand_data], prediction[rand_data]))
    plt.show()


# ------------------------------------------------------------------------------
# main starts from here
run_random_imges()